export const mainPage = {
  template: require('./page.html'),
  bindings: {
    markdown: '<'
  }
};
